# COVID-19 Prediction and Analysis Using Machine Learning
## Complete Academic Project Report & Viva Preparation Guide

---

## 1. Abstract
The COVID-19 pandemic highlighted the critical need for robust computational tools to analyze epidemiological curves and forecast short-term infection patterns. This project presents an end-to-end data science and machine learning system developed to analyze historical global COVID-19 transmission dynamics and predict future daily case trajectories. Using the curated Johns Hopkins University (JHU) CSSE dataset encompassing 161,568 daily records across 198 countries between January 2020 and April 2022, the system performs rigorous data sanitization, exploratory analysis, and leak-free time-series feature engineering.

Candidate predictive models—Linear Regression, Random Forest Regressor, and Gradient Boosting Regressor—were evaluated using strict chronological train/test splitting ($80\%$ train, $20\%$ test) to replicate real-world forward deployment without temporal leakage. Linear Regression emerged as the superior model, achieving a Mean Absolute Error ($MAE$) of **153,028.9**, a Root Mean Squared Error ($RMSE$) of **227,294.9**, and a coefficient of determination ($R^2$) of **0.9432** on the unseen test set containing the global Omicron wave. In contrast, tree ensembles failed to extrapolate beyond training bounds. The model is deployed within an interactive, modular Streamlit web dashboard featuring real-time KPI monitoring, multi-day recursive forecasting, and dataset inspection capabilities.

---

## 2. Introduction
Since late 2019, the novel coronavirus (COVID-19) disease spread globally, creating unprecedented disruptions to public healthcare infrastructures and socioeconomic stability. Epidemiological data analysis and time-series modeling serve as primary analytical tools to quantify infection velocities, assess fatality rates, and assist in resource distribution planning. 

In computer science and data analytics curricula, building a predictive epidemiological system provides practical exposure to time-series processing, regression modeling, data leakage mitigation, and interactive dashboard engineering. This project implements a modular, reproducible software architecture designed to ingest raw public health records, process multi-regional time series, benchmark predictive algorithms, and present actionable visual insights to non-technical stakeholders.

---

## 3. Problem Statement
Public health surveillance datasets are characterized by reporting inconsistencies, retrospective clerical corrections, and abrupt distribution shifts caused by emerging viral variants. Standard regression workflows often fail when applied to such data due to two common pitfalls:
1. **Temporal Data Leakage**: Randomly shuffling time-series data or calculating moving averages that include the target day's value results in artificially inflated validation scores that collapse upon real-world deployment.
2. **Model Extrapolation Inability**: Modern non-linear algorithms, specifically decision tree ensembles, partition feature space into discrete bounded regions and inherently cannot predict numerical values outside the range observed during training.

The objective of this project is to construct a methodologically sound predictive and exploratory system that enforces strict chronological validation, generates leak-free lag features, transparently benchmarks linear versus non-linear regressors, and provides an intuitive, web-based demonstration platform.

---

## 4. Objectives
* **Data Hygiene and Pipeline Automation**: Build a pipeline to ingest, validate, and clean raw multi-national COVID-19 records from the Johns Hopkins CSSE repository.
* **Exploratory Epidemiological Analysis (EDA)**: Compute vital statistics including total confirmed cases, fatalities, recovery patterns, active case estimates, moving averages, and country-level rankings.
* **Leak-Free Temporal Feature Engineering**: Extract autoregressive lags ($t-1, t-2, t-3, t-7, t-14$) and historical rolling statistics computed exclusively on prior observations ($t-1$).
* **Chronological Model Benchmarking**: Train and compare Linear Regression, Random Forest, and Gradient Boosting on an unseen test split without random shuffling.
* **Interactive Visualization & Web Deployment**: Create a responsive Streamlit application featuring KPI cards, Plotly charts, multi-day forecasting, and custom dataset upload functionality.

---

## 5. Scope of the Project
* **Included in Scope**:
  * Global and country-level time-series analysis for 198 countries from January 22, 2020 to April 16, 2022.
  * Regression-based short-term forecasting (3 to 30 days ahead) for daily new infections.
  * Model evaluation using $MAE$, $RMSE$, and $R^2$ scores.
  * Web-based dashboard deployment via Streamlit.
* **Excluded from Scope**:
  * Mechanistic epidemiological simulation models (e.g., SEIR compartmental differential equations).
  * Clinical diagnosis, patient-level triage, or vaccine efficacy modeling.
  * Direct medical recommendations or clinical decision support.

---

## 6. Existing System vs. Proposed System

### 6.1 Existing System Limitations
* **Static Visualizations**: Existing academic demos frequently rely on static, pre-rendered Matplotlib plots saved as images without user interactivity.
* **Randomized Validation Splits**: Many existing student projects incorrectly apply `train_test_split(shuffle=True)` on time series, causing future observations to leak into the training partition.
* **Lack of Model Comparison**: Most projects evaluate only a single algorithm without examining why specific models succeed or fail across changing pandemic waves.
* **Poor Extensibility**: Tightly coupled scripts with hardcoded file paths that break when new datasets are introduced.

### 6.2 Proposed System Enhancements
* **Modular Architecture**: Clean separation into `data_loader`, `data_cleaning`, `analysis`, `visualization`, and `prediction` modules.
* **Strict Temporal Integrity**: Chronological train-test splitting and backward-shifted rolling statistics ensure zero lookahead bias.
* **Multi-Model Empirical Benchmark**: Direct comparison between linear modeling and ensemble tree architectures with mathematical explanations of extrapolation boundaries.
* **Interactive Web Platform**: Modern Streamlit user interface featuring dynamic Plotly tooltips, country selection, forecasting horizons, and custom CSV ingestion.

---

## 7. System Architecture

```mermaid
flowchart TD
    A["Raw Public Dataset<br/>(JHU CSSE 161,568 rows)"] --> B["data_loader.py<br/>(Validation & Safe Ingestion)"]
    B --> C["data_cleaning.py<br/>(Date Parsing, Zero-Clipping, Derived Features)"]
    
    C --> D["analysis.py<br/>(Global & Regional Analytics)"]
    C --> E["prediction.py<br/>(Lag Engineering & Chronological Split)"]
    
    D --> F["visualization.py<br/>(Plotly & Seaborn Charts)"]
    
    E --> G["Candidate Models<br/>(Linear Reg, Random Forest, Gradient Boosting)"]
    G --> H["Model Evaluation<br/>(MAE, RMSE, R²)"]
    H --> I["Best Model Artifact<br/>(covidpredictionmodel.pkl)"]
    
    F --> J["app.py (Streamlit Web Dashboard)"]
    I --> J
    
    J --> K["User Browser<br/>(KPIs, Analysis, Predictions, Uploads)"]
```

---

## 8. Technologies Used
* **Programming Language**: Python 3.13.5
* **Core Data Manipulation**: Pandas (v3.0.6), NumPy (v2.5.3)
* **Statistical Modeling & ML**: Scikit-Learn (v1.9.1), Joblib (v1.6.0)
* **Visualization Libraries**: Plotly (v7.1.0), Seaborn (v0.13.2), Matplotlib (v3.11.2)
* **Web Application Framework**: Streamlit (v1.65.0)
* **Exploratory Prototyping**: Jupyter Notebook (v1.1.1)

---

## 9. Hardware & Software Requirements

### 9.1 Hardware Requirements
* **Processor**: Dual-Core x86_64 or ARM processor (Intel Core i3 / AMD Ryzen 3 or higher).
* **RAM**: Minimum 4 GB (8 GB recommended for caching in-memory operations).
* **Storage**: Minimum 500 MB of free hard drive space.

### 9.2 Software Requirements
* **Operating System**: Windows 10/11, Ubuntu 20.04+, or macOS 12+.
* **Runtime**: Python 3.10 to 3.13.
* **Web Browser**: Modern browser (Google Chrome, Mozilla Firefox, Microsoft Edge, Safari).

---

## 10. Dataset Description
* **Primary Source**: Curated Johns Hopkins University (JHU) Center for Systems Science and Engineering COVID-19 Data Repository.
* **Distribution Channel**: Frictionless Data Open Archive (`datasets/covid-19`).
* **Temporal Range**: January 22, 2020 – April 16, 2022 (816 continuous calendar days).
* **Geographical Coverage**: 198 recognized countries and sovereign regions.
* **Total Volume**: 161,568 raw observation rows across 5 base columns:
  * `Date` (string/ISO-8601 formatted date: `YYYY-MM-DD`).
  * `Country` (string identifier for sovereign nation or territory).
  * `Confirmed` (cumulative count of laboratory-confirmed positive COVID-19 cases).
  * `Recovered` (cumulative count of recovered patients; tracked globally until August 2021).
  * `Deaths` (cumulative count of confirmed COVID-19 related fatalities).

---

## 11. Data Preprocessing Pipeline

The data sanitization pipeline implemented in `src/data_cleaning.py` follows a defined 6-stage protocol:

1. **Header Normalization**: Columns are standardized into lowercase snake_case (`date`, `country`, `confirmed`, `recovered`, `deaths`).
2. **Temporal Parsing & Sorting**: The `date` column is cast to `pd.datetime64[ns]`. Data is sorted hierarchically by `['country', 'date']` to ensure sequential time-series ordering.
3. **Duplicate Elimination**: Verified that each `(country, date)` combination is uniquely indexed; redundant rows are dropped.
4. **Non-Negative Sanitization**: Public reporting occasionally includes retrospective negative corrections. Cumulative counters are constrained to non-negative domains using `.clip(lower=0)`.
5. **Grouped Difference Calculation**: Daily increments are computed per country using grouped first differences:
   $$\text{daily\_cases}_t = \max(0, \text{confirmed}_t - \text{confirmed}_{t-1})$$
   $$\text{daily\_deaths}_t = \max(0, \text{deaths}_t - \text{deaths}_{t-1})$$
6. **Active Case Estimation**: Active infections are computed as:
   $$\text{active\_cases}_t = \max(0, \text{confirmed}_t - \text{recovered}_t - \text{deaths}_t)$$

---

## 12. Exploratory Data Analysis & Findings

All statistical metrics were calculated directly from the actual dataset:

### 12.1 Key Summary Metrics

| Indicator | Calculated Value | Context / Epidemiological Meaning |
| :--- | :---: | :--- |
| **Total Global Confirmed** | **504,155,459** | Cumulative global infections recorded by April 16, 2022 |
| **Total Global Fatalities** | **6,197,159** | Cumulative confirmed COVID-19 related deaths |
| **Global Case Fatality Rate (CFR)** | **1.23%** | Calculated as $\frac{\text{Total Deaths}}{\text{Total Confirmed}} \times 100$ |
| **Peak Historical Recoveries** | **130,899,061** | Recorded on August 4, 2021 *(reporting paused by JHU thereafter)* |
| **Active Cases Estimate** | **497,958,300** | Estimated active caseload as of April 16, 2022 |
| **Peak Daily Cases (Global)** | **4,089,026** | Single-day global record occurring on **January 19, 2022** (Omicron wave) |
| **Peak Daily Deaths (Global)** | **20,726** | Single-day global mortality record occurring on **July 20, 2021** (Delta wave) |
| **Mean Daily Cases** | **618,650.75** | Global average new infections per day across 816 days |
| **Mean Daily Deaths** | **7,601.81** | Global average fatalities per day across 816 days |

### 12.2 Top 10 Most Affected Nations (by Confirmed Cases)

| Rank | Country | Cumulative Confirmed | Cumulative Deaths | Case Fatality Rate (%) |
| :---: | :--- | :---: | :---: | :---: |
| 1 | **United States** | 80,625,120 | 988,609 | 1.23% |
| 2 | **India** | 43,042,097 | 521,751 | 1.21% |
| 3 | **Brazil** | 30,250,077 | 662,185 | 2.19% |
| 4 | **France** | 27,874,269 | 145,159 | 0.52% |
| 5 | **Germany** | 23,416,663 | 132,942 | 0.57% |
| 6 | **United Kingdom** | 21,916,961 | 172,014 | 0.78% |
| 7 | **Russia** | 17,801,103 | 365,774 | 2.05% |
| 8 | **South Korea** | 16,305,752 | 21,092 | 0.13% |
| 9 | **Italy** | 15,659,835 | 161,602 | 1.03% |
| 10 | **Turkey** | 14,991,669 | 98,551 | 0.66% |

---

## 13. Machine Learning Methodology

### 13.1 Feature Engineering (Zero Lookahead Leakage)
To forecast daily cases $y_t$ at date $t$, the model must only use information available prior to date $t$:
* **Autoregressive Lag Features**:
  $$x_{\text{lag}, k} = y_{t-k} \quad \text{for } k \in \{1, 2, 3, 7, 14\}$$
* **Backward Rolling Moving Means & Variances**:
  Computed on $y_{t-1}$ to prevent the target value $y_t$ from leaking into the window:
  $$x_{\text{roll\_mean}, W} = \frac{1}{W} \sum_{i=1}^{W} y_{t-i} \quad \text{for } W \in \{7, 14\}$$
  $$x_{\text{roll\_std}, W} = \sqrt{\frac{1}{W-1} \sum_{i=1}^{W} (y_{t-i} - \bar{y}_{W})^2}$$
* **Calendar Seasonality Features**: Day-of-week ($0$ to $6$, capturing weekend reporting depressions) and Day-of-year ($1$ to $365$).

### 13.2 Chronological Train/Test Partitioning
* **Training Set**: February 5, 2020 – November 6, 2021 (641 daily observations, $80\%$).
* **Testing Set**: November 7, 2021 – April 16, 2022 (161 daily observations, $20\%$).
* **No Shuffling**: Traditional K-fold cross-validation or randomized splits mix past and future data, producing misleadingly high scores. Chronological partitioning guarantees true forward testing on unseen viral waves.

---

## 14. Algorithms Used

### 14.1 Ordinary Least Squares (Linear Regression)
Models the relationship between predictors $\mathbf{X}$ and target $y$ via linear coefficients:
$$y_t = \beta_0 + \sum_{j=1}^{p} \beta_j X_{t, j} + \epsilon_t$$
Coefficients are solved analytically by minimizing the residual sum of squares:
$$\hat{\boldsymbol{\beta}} = (\mathbf{X}^T \mathbf{X})^{-1} \mathbf{X}^T \mathbf{y}$$

### 14.2 Random Forest Regressor
An ensemble learning technique that fits $B = 100$ independent decision trees using bootstrap aggregation (bagging) and random feature subsets:
$$\hat{y}_t = \frac{1}{B} \sum_{b=1}^{B} T_b(\mathbf{x}_t)$$

### 14.3 Gradient Boosting Regressor
An additive boosting ensemble that builds decision trees sequentially, with each subsequent tree fitted to the negative gradient (pseudo-residuals) of the loss function:
$$\hat{y}_t^{(m)} = \hat{y}_t^{(m-1)} + \eta \cdot h_m(\mathbf{x}_t)$$
where $\eta = 0.1$ is the learning rate and $h_m$ is the $m$-th regression tree.

---

## 15. Model Evaluation Metrics & Results

### 15.1 Mathematical Formulations
* **Mean Absolute Error (MAE)**:
  $$\text{MAE} = \frac{1}{N} \sum_{i=1}^{N} |y_i - \hat{y}_i|$$
* **Root Mean Squared Error (RMSE)**:
  $$\text{RMSE} = \sqrt{\frac{1}{N} \sum_{i=1}^{N} (y_i - \hat{y}_i)^2}$$
* **Coefficient of Determination ($R^2$)**:
  $$R^2 = 1 - \frac{\sum_{i=1}^{N} (y_i - \hat{y}_i)^2}{\sum_{i=1}^{N} (y_i - \bar{y})^2}$$

### 15.2 Empirical Evaluation Benchmark (On Unseen Test Set)

| Candidate Model | MAE | RMSE | $R^2$ Score | Verdict |
| :--- | :---: | :---: | :---: | :--- |
| **Linear Regression** | **153,028.9** | **227,294.9** | **0.9432** | ⭐ **Best Performing Model** |
| **Random Forest Regressor** | 833,483.3 | 1,193,694.2 | -0.5660 | Suboptimal Extrapolation |
| **Gradient Boosting Regressor** | 863,587.3 | 1,224,839.4 | -0.6488 | Suboptimal Extrapolation |

---

## 16. Technical Discussion: Why Did Linear Regression Outperform Ensemble Trees?

One of the most notable academic insights of this project is the marked performance divergence between Linear Regression ($R^2 = 0.9432$) and tree-based ensembles ($R^2 < 0$).

1. **Extrapolation Ceiling of Tree Architectures**: 
   Decision trees partition the feature space into axis-aligned hyper-rectangles. For any unseen input $\mathbf{x}$, the prediction is simply the mean value of the training samples residing in that leaf:
   $$\hat{y}_{\text{tree}}(\mathbf{x}) \le \max_{i \in \text{Train}} y_i$$
   During the training window (Feb 2020 – Nov 2021), global daily cases never exceeded $\approx 900,000$ cases/day. However, during the test window (Nov 2021 – Apr 2022), the Omicron variant drove infections to an unprecedented peak of **4,089,026 cases/day**. Both Random Forest and Gradient Boosting hit their training ceilings and failed to predict any value above $\approx 900,000$, resulting in severe under-prediction and negative $R^2$.

2. **Proportional Linear Scaling**:
   Linear Regression models continuous slope coefficients:
   $$y_t \approx 0.82 \cdot y_{t-1} + 0.15 \cdot y_{t-7} + \dots$$
   Because it models proportional growth rates rather than memorizing localized feature boxes, Linear Regression dynamically scaled its predictions alongside the rising Omicron wave, accurately capturing the surge and yielding an $R^2$ of **0.9432**.

---

## 17. Implementation & Deployment
* **Web Framework**: Built with Streamlit (`app.py`), configuring wide-screen responsive layouts and modular component rendering.
* **Caching Strategy**: Implemented `@st.cache_data` for data ingestion and `@st.cache_resource` for serialized model loading, reducing page re-render latency to $< 100$ milliseconds.
* **Model Serialization**: Preserved the fitted model artifact in `models/covidpredictionmodel.pkl` along with feature metadata in `models/feature_config.json`.
* **Recursive Multi-Day Forecasting Engine**: Engineered `forecast_future_days()` in `src/prediction.py`, which generates multi-step predictions recursively by feeding predicted cases back into subsequent lag vectors.

---

## 18. Limitations
1. **Reporting Anomalies**: Data reflects recorded positive tests rather than true epidemiological prevalence; testing capacity changes and national reporting standard variations introduce noise.
2. **Recovery Tracking Discontinuation**: Recovery figures plateau after August 2021 because international authorities (including the US and UK) ceased publishing recovered totals.
3. **External Exogenous Variables**: The model forecasts using purely autoregressive time-series features without factoring in exogenous policy interventions (e.g., lockdowns, mask mandates) or genomic sequencing variants.
4. **Recursive Error Accumulation**: In multi-step recursive forecasting ($>14$ days), errors from earlier forecast steps propagate into subsequent lag vectors.

---

## 19. Future Scope
* **Exogenous Policy Integration**: Incorporate the Oxford COVID-19 Government Response Tracker (OxCGRT) stringency index to capture policy interventions.
* **Deep Sequence Models**: Benchmark recurrent neural architectures such as Long Short-Term Memory (LSTM) and Temporal Fusion Transformers (TFT).
* **Hybrid Mechanistic-ML Modeling**: Combine epidemiological compartmental models (SEIR) with residual machine learning regressors.
* **Sub-National Granularity**: Expand the pipeline to ingest state-, district-, and county-level surveillance data.

---

## 20. Conclusion
This project successfully designed and implemented an end-to-end COVID-19 analysis and prediction pipeline. Through rigorous leak-free feature engineering and chronological train-test validation, the system demonstrated that Linear Regression ($R^2 = 0.9432$, $\text{RMSE} = 227,294.9$) significantly outperforms complex decision tree ensembles when predicting unprecedented epidemic waves. The resulting interactive Streamlit dashboard provides transparent visualizations, multi-day forecasting, and clear disclaimers, fulfilling all requirements for a professional final-year academic project.

---

## 21. References
1. Dong, E., Du, H., & Gardner, L. (2020). *An interactive web-based dashboard to track COVID-19 in real time*. The Lancet Infectious Diseases, 20(5), 533-534.
2. Pedregosa, F., et al. (2011). *Scikit-learn: Machine Learning in Python*. Journal of Machine Learning Research, 12, 2825-2830.
3. McKinney, W. (2010). *Data Structures for Statistical Computing in Python*. Proceedings of the 9th Python in Science Conference, 51-56.
4. Hyndman, R. J., & Athanasopoulos, G. (2018). *Forecasting: principles and practice*. OTexts: Melbourne, Australia.
5. Frictionless Data & Datasets Project. *COVID-19 Curated Time Series Archive*. GitHub Repository: `https://github.com/datasets/covid-19`.

---
---

# Comprehensive Viva Voce Questions & Answers

### Q1: What is the main objective of your project?
**Answer:** The project aims to analyze global COVID-19 transmission patterns using historical data from Johns Hopkins University and build machine learning regression models to predict future daily cases while strictly avoiding time-series data leakage.

### Q2: Why did you use chronological train/test splitting instead of randomized splitting?
**Answer:** In time-series forecasting, randomized train/test splitting (like standard `train_test_split(shuffle=True)`) creates catastrophic data leakage because future observations leak into the training set while past observations appear in the test set. Chronological splitting (training on the first $80\%$ of dates and testing on the last $20\%$) simulates real-world deployment, where the model only learns from the past to predict the future.

### Q3: What features did you engineer for the predictive model?
**Answer:** We created:
1. Autoregressive lags: $t-1, t-2, t-3, t-7, t-14$.
2. Backward-looking rolling statistics: 7-day and 14-day rolling means and standard deviations computed exclusively on $t-1$ backwards.
3. Calendar indicators: Day-of-week (capturing weekend reporting depressions) and Day-of-year.

### Q4: How did you ensure there was no data leakage in your rolling average features?
**Answer:** When computing rolling statistics for day $t$, we shifted the series by 1 day first (`shift(1)`). This ensures the window covers days $t-W$ through $t-1$, completely excluding the actual target value of day $t$.

### Q5: Which machine learning model performed best, and what were its metrics?
**Answer:** **Linear Regression** performed best on the unseen chronological test set, achieving:
* $R^2$ Score: **0.9432**
* MAE: **153,028.9**
* RMSE: **227,294.9**

### Q6: Why did Random Forest and Gradient Boosting produce negative $R^2$ scores?
**Answer:** Tree-based models partition the training feature space and predict by averaging training samples in the leaf nodes. They cannot predict any value higher than the maximum target observed during training ($\approx 900,000$ cases/day). During our test period, the global Omicron wave hit a peak of **4,089,026 cases/day**. Tree models were capped by their training ceiling and severely under-predicted, resulting in a residual sum of squares worse than predicting the mean (negative $R^2$). Linear Regression succeeded because it models continuous proportional relationships ($y_t \propto y_{t-1}$), naturally scaling upward with unseen waves.

### Q7: Why is total recovery reported as 0 on the latest date in your dataset?
**Answer:** Johns Hopkins University CSSE officially stopped compiling global recovery statistics on August 4, 2021, because international health ministries (including the CDC and NHS) ceased tracking recovered cases and focused on hospitalization and vaccination metrics. The historical peak recorded in our dataset was **130,899,061** on August 4, 2021.

### Q8: What is the difference between MAE and RMSE?
**Answer:**
* **MAE (Mean Absolute Error)** measures the average magnitude of errors linearly, giving equal weight to all deviations: $\frac{1}{N}\sum |y - \hat{y}|$.
* **RMSE (Root Mean Squared Error)** squares errors before taking the root: $\sqrt{\frac{1}{N}\sum (y - \hat{y})^2}$. This heavily penalizes large outlier errors, making it especially sensitive to major prediction spikes during epidemic surges.

### Q9: How does your recursive multi-day forecasting work?
**Answer:** When forecasting $N$ days ahead, the model predicts day $t+1$ using historical lags. For day $t+2$, the newly predicted value for $t+1$ is appended to the historical sequence and treated as the lag $t-1$ feature. This process repeats recursively up to the selected forecast horizon.

### Q10: Does this project provide clinical medical advice?
**Answer:** Absolutely not. The project is an academic computer science demonstration. Predictions are statistical approximations derived from public reporting numbers. The dashboard includes prominent disclaimers stating that outputs must not be used as clinical advice, diagnostic tools, or public health policy directives.
