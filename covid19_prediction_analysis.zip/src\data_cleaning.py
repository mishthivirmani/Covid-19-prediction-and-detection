"""COVID-19 Data Cleaning and Feature Engineering Pipeline.

This module provides functions to preprocess, clean, and engineer
time-series features from raw COVID-19 datasets without future lookahead.
"""

from typing import Dict, Any, Optional
import numpy as np
import pandas as pd

try:
    from src.data_loader import load_covid_data
except ImportError:
    from data_loader import load_covid_data


def clean_covid_data(df: pd.DataFrame, verbose: bool = True) -> pd.DataFrame:
    """Cleans the raw COVID-19 dataset and generates derived time-series features.

    Cleaning steps performed:
    1. Standardize column names (lowercase, stripped, snake_case).
    2. Convert date strings to pandas datetime format.
    3. Remove duplicate rows.
    4. Sort data chronologically by country and date.
    5. Cast numerical columns (confirmed, recovered, deaths) to numeric and handle nulls/negatives.
    6. Derive non-leaking time-series features:
       - daily_cases
       - daily_deaths
       - daily_recoveries
       - active_cases
       - cases_7d_ma (7-day rolling moving average of daily cases)
       - cases_14d_ma (14-day rolling moving average of daily cases)
       - daily_growth_rate (daily percentage change in confirmed cases)

    Parameters
    ----------
    df : pd.DataFrame
        The raw COVID-19 dataframe.
    verbose : bool, default=True
        Whether to print summary progress messages.

    Returns
    -------
    pd.DataFrame
        The cleaned dataframe with standardized types and derived features.
    """
    # Create an explicit copy to avoid mutating the original input DataFrame
    cleaned_df = df.copy()

    # Step 1: Standardize column names
    cleaned_df.columns = [str(col).strip().lower().replace(" ", "_") for col in cleaned_df.columns]

    # Step 2: Convert date column to pandas datetime
    if "date" in cleaned_df.columns:
        cleaned_df["date"] = pd.to_datetime(cleaned_df["date"], errors="coerce")

    # Step 3: Remove duplicate rows
    # Check for general duplicates as well as unique (country, date) pairs
    if "country" in cleaned_df.columns and "date" in cleaned_df.columns:
        cleaned_df = cleaned_df.drop_duplicates(subset=["country", "date"])
    else:
        cleaned_df = cleaned_df.drop_duplicates()

    # Step 4: Sort data chronologically
    # Sorting by country and date ensures time-series features are correctly calculated per region
    sort_cols = [c for c in ["country", "date"] if c in cleaned_df.columns]
    if sort_cols:
        cleaned_df = cleaned_df.sort_values(by=sort_cols).reset_index(drop=True)

    # Step 5: Handle numeric columns and invalid/negative values
    # In public datasets, cumulative metrics must be non-negative
    numeric_cols = ["confirmed", "recovered", "deaths"]
    for col in numeric_cols:
        if col in cleaned_df.columns:
            cleaned_df[col] = pd.to_numeric(cleaned_df[col], errors="coerce").fillna(0)
            # Clip negative counts that may arise from clerical reporting errors
            cleaned_df[col] = cleaned_df[col].clip(lower=0)

    # Step 6: Derive features (grouped by country where available)
    # Important: All moving averages and difference calculations use PAST data only
    # (no future information is leaked).
    if "country" in cleaned_df.columns:
        # Grouped diff for daily values:
        # For the first day, diff() is NaN, so we fill with initial cumulative value
        cleaned_df["daily_cases"] = (
            cleaned_df.groupby("country")["confirmed"]
            .diff()
            .fillna(cleaned_df["confirmed"])
            .clip(lower=0)
        )
        cleaned_df["daily_deaths"] = (
            cleaned_df.groupby("country")["deaths"]
            .diff()
            .fillna(cleaned_df["deaths"])
            .clip(lower=0)
        )
        cleaned_df["daily_recoveries"] = (
            cleaned_df.groupby("country")["recovered"]
            .diff()
            .fillna(cleaned_df["recovered"])
            .clip(lower=0)
        )

        # Active cases = Confirmed - Recovered - Deaths (clipped to >= 0)
        cleaned_df["active_cases"] = (
            cleaned_df["confirmed"] - cleaned_df["recovered"] - cleaned_df["deaths"]
        ).clip(lower=0)

        # 7-day and 14-day rolling moving averages (historical window only, min_periods=1)
        cleaned_df["cases_7d_ma"] = cleaned_df.groupby("country")["daily_cases"].transform(
            lambda s: s.rolling(window=7, min_periods=1).mean()
        )
        cleaned_df["cases_14d_ma"] = cleaned_df.groupby("country")["daily_cases"].transform(
            lambda s: s.rolling(window=14, min_periods=1).mean()
        )

        # Daily growth rate = percentage change in confirmed cases
        cleaned_df["daily_growth_rate"] = (
            cleaned_df.groupby("country")["confirmed"]
            .pct_change()
            .replace([np.inf, -np.inf], np.nan)
            .fillna(0.0)
            .clip(lower=0.0)
        )
    else:
        # Global fallback if country column is not present
        cleaned_df["daily_cases"] = cleaned_df["confirmed"].diff().fillna(cleaned_df["confirmed"]).clip(lower=0)
        cleaned_df["daily_deaths"] = cleaned_df["deaths"].diff().fillna(cleaned_df["deaths"]).clip(lower=0)
        cleaned_df["daily_recoveries"] = cleaned_df["recovered"].diff().fillna(cleaned_df["recovered"]).clip(lower=0)
        cleaned_df["active_cases"] = (cleaned_df["confirmed"] - cleaned_df["recovered"] - cleaned_df["deaths"]).clip(lower=0)
        cleaned_df["cases_7d_ma"] = cleaned_df["daily_cases"].rolling(window=7, min_periods=1).mean()
        cleaned_df["cases_14d_ma"] = cleaned_df["daily_cases"].rolling(window=14, min_periods=1).mean()
        cleaned_df["daily_growth_rate"] = cleaned_df["confirmed"].pct_change().replace([np.inf, -np.inf], np.nan).fillna(0.0).clip(lower=0.0)

    # Final sweep: fill any remaining NaNs in derived features with 0
    cleaned_df = cleaned_df.fillna(0)

    if verbose:
        print("[INFO] Data cleaning and feature engineering completed.")

    return cleaned_df


def inspect_cleaning_pipeline(raw_df: pd.DataFrame, cleaned_df: pd.DataFrame) -> Dict[str, Any]:
    """Generates comparison metrics between raw and cleaned datasets.

    Parameters
    ----------
    raw_df : pd.DataFrame
        Raw dataset before cleaning.
    cleaned_df : pd.DataFrame
        Processed dataset after cleaning.

    Returns
    -------
    dict
        Dictionary containing shape comparison, null count comparison, and column names.
    """
    summary = {
        "original_shape": raw_df.shape,
        "cleaned_shape": cleaned_df.shape,
        "missing_before": raw_df.isnull().sum().to_dict(),
        "missing_after": cleaned_df.isnull().sum().to_dict(),
        "final_columns": list(cleaned_df.columns),
    }
    return summary


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("TESTING COVID-19 DATA CLEANING PIPELINE")
    print("=" * 60)

    # 1. Load actual dataset using data_loader
    raw_data = load_covid_data(verbose=False)

    # 2. Run data cleaning pipeline
    clean_data = clean_covid_data(raw_data, verbose=True)

    # 3. Inspect and display results
    metrics = inspect_cleaning_pipeline(raw_data, clean_data)

    print("\n--- Pipeline Verification Report ---")
    print(f"Original dataset shape : {metrics['original_shape']}")
    print(f"Cleaned dataset shape  : {metrics['cleaned_shape']}")

    print("\nMissing values BEFORE cleaning:")
    for col, count in metrics["missing_before"].items():
        print(f"  - {col}: {count}")

    print("\nMissing values AFTER cleaning:")
    for col, count in metrics["missing_after"].items():
        print(f"  - {col}: {count}")

    print("\nFinal column names:")
    for idx, col in enumerate(metrics["final_columns"], start=1):
        print(f"  {idx}. {col}")

    print("\nSample Preview (First 5 Rows of Cleaned Data):")
    cols_to_preview = ["date", "country", "confirmed", "daily_cases", "active_cases", "cases_7d_ma", "daily_growth_rate"]
    print(clean_data[cols_to_preview].head())
    print("\n[SUCCESS] Cleaning pipeline test passed without errors.\n")
