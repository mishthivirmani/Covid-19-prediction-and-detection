"""COVID-19 Visualization Module.

Generates interactive charts (using Plotly) and publication-quality static
plots (using Seaborn and Matplotlib) for exploratory data analysis of COVID-19 trends.
"""

from pathlib import Path
from typing import Optional, Dict
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend safe for headless scripts and automated tests
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd

try:
    from src.data_loader import load_covid_data
    from src.data_cleaning import clean_covid_data
    from src.analysis import (
        get_global_time_series,
        get_top_affected_countries,
        calculate_correlation_matrix,
    )
except ImportError:
    from data_loader import load_covid_data
    from data_cleaning import clean_covid_data
    from analysis import (
        get_global_time_series,
        get_top_affected_countries,
        calculate_correlation_matrix,
    )


# -----------------------------------------------------------------------------
# PLOTLY INTERACTIVE CHARTS
# -----------------------------------------------------------------------------

def plot_cases_over_time_plotly(
    ts_df: pd.DataFrame, title: str = "Cumulative COVID-19 Cases Over Time"
) -> go.Figure:
    """Creates an interactive line chart of cumulative confirmed cases over time."""
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=ts_df["date"],
            y=ts_df["confirmed"],
            mode="lines",
            name="Confirmed Cases",
            line=dict(color="#1f77b4", width=2.5),
            hovertemplate="<b>Date</b>: %{x|%Y-%m-%d}<br><b>Confirmed</b>: %{y:,.0f}<extra></extra>",
        )
    )
    fig.update_layout(
        title=dict(text=title, font=dict(size=18)),
        xaxis_title="Date",
        yaxis_title="Cumulative Cases",
        template="plotly_white",
        hovermode="x unified",
        margin=dict(l=40, r=40, t=60, b=40),
    )
    return fig


def plot_daily_cases_and_ma_plotly(
    ts_df: pd.DataFrame, title: str = "Daily New Cases & Moving Averages"
) -> go.Figure:
    """Creates an interactive chart with daily cases (bars) and 7-day / 14-day MAs (lines)."""
    fig = go.Figure()

    # Daily new cases as bars
    fig.add_trace(
        go.Bar(
            x=ts_df["date"],
            y=ts_df["daily_cases"],
            name="Daily New Cases",
            marker=dict(color="rgba(31, 119, 180, 0.45)"),
            hovertemplate="<b>Date</b>: %{x|%Y-%m-%d}<br><b>Daily Cases</b>: %{y:,.0f}<extra></extra>",
        )
    )

    # 7-day moving average line
    fig.add_trace(
        go.Scatter(
            x=ts_df["date"],
            y=ts_df["cases_7d_ma"],
            mode="lines",
            name="7-Day Moving Avg",
            line=dict(color="#ff7f0e", width=2.5),
            hovertemplate="<b>7-Day MA</b>: %{y:,.0f}<extra></extra>",
        )
    )

    # 14-day moving average line
    if "cases_14d_ma" in ts_df.columns:
        fig.add_trace(
            go.Scatter(
                x=ts_df["date"],
                y=ts_df["cases_14d_ma"],
                mode="lines",
                name="14-Day Moving Avg",
                line=dict(color="#2ca02c", width=2.0, dash="dash"),
                hovertemplate="<b>14-Day MA</b>: %{y:,.0f}<extra></extra>",
            )
        )

    fig.update_layout(
        title=dict(text=title, font=dict(size=18)),
        xaxis_title="Date",
        yaxis_title="Cases",
        template="plotly_white",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        hovermode="x unified",
        margin=dict(l=40, r=40, t=60, b=40),
    )
    return fig


def plot_deaths_over_time_plotly(
    ts_df: pd.DataFrame, title: str = "COVID-19 Deaths Over Time (Daily & Cumulative)"
) -> go.Figure:
    """Creates a dual-axis interactive chart showing daily deaths and cumulative deaths."""
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    fig.add_trace(
        go.Bar(
            x=ts_df["date"],
            y=ts_df["daily_deaths"],
            name="Daily Deaths",
            marker=dict(color="rgba(214, 39, 40, 0.45)"),
            hovertemplate="<b>Date</b>: %{x|%Y-%m-%d}<br><b>Daily Deaths</b>: %{y:,.0f}<extra></extra>",
        ),
        secondary_y=False,
    )

    fig.add_trace(
        go.Scatter(
            x=ts_df["date"],
            y=ts_df["deaths"],
            mode="lines",
            name="Cumulative Deaths",
            line=dict(color="#d62728", width=2.5),
            hovertemplate="<b>Cumulative Deaths</b>: %{y:,.0f}<extra></extra>",
        ),
        secondary_y=True,
    )

    fig.update_layout(
        title=dict(text=title, font=dict(size=18)),
        template="plotly_white",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        hovermode="x unified",
        margin=dict(l=40, r=40, t=60, b=40),
    )
    fig.update_xaxes(title_text="Date")
    fig.update_yaxes(title_text="Daily Deaths", secondary_y=False)
    fig.update_yaxes(title_text="Cumulative Deaths", secondary_y=True)
    return fig


def plot_recoveries_over_time_plotly(
    ts_df: pd.DataFrame, title: str = "COVID-19 Recoveries Over Time"
) -> go.Figure:
    """Plots recorded recoveries with historical reporting note."""
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=ts_df["date"],
            y=ts_df["recovered"],
            mode="lines",
            name="Recorded Recoveries",
            line=dict(color="#2ca02c", width=2.5),
            hovertemplate="<b>Date</b>: %{x|%Y-%m-%d}<br><b>Recovered</b>: %{y:,.0f}<extra></extra>",
        )
    )
    fig.update_layout(
        title=dict(text=title, font=dict(size=18)),
        xaxis_title="Date",
        yaxis_title="Recorded Recoveries",
        template="plotly_white",
        hovermode="x unified",
        margin=dict(l=40, r=40, t=60, b=40),
    )
    return fig


def plot_active_cases_plotly(
    ts_df: pd.DataFrame, title: str = "Estimated Active Cases Over Time"
) -> go.Figure:
    """Plots active cases trajectory over time."""
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=ts_df["date"],
            y=ts_df["active_cases"],
            mode="lines",
            name="Active Cases",
            line=dict(color="#9467bd", width=2.5),
            fill="tozeroy",
            fillcolor="rgba(148, 103, 189, 0.15)",
            hovertemplate="<b>Date</b>: %{x|%Y-%m-%d}<br><b>Active Cases</b>: %{y:,.0f}<extra></extra>",
        )
    )
    fig.update_layout(
        title=dict(text=title, font=dict(size=18)),
        xaxis_title="Date",
        yaxis_title="Active Cases",
        template="plotly_white",
        hovermode="x unified",
        margin=dict(l=40, r=40, t=60, b=40),
    )
    return fig


def plot_growth_rate_plotly(
    ts_df: pd.DataFrame, title: str = "Daily Growth Rate (%) Over Time"
) -> go.Figure:
    """Plots percentage daily growth rate over time."""
    fig = go.Figure()
    growth_pct = ts_df["daily_growth_rate"] * 100
    fig.add_trace(
        go.Scatter(
            x=ts_df["date"],
            y=growth_pct,
            mode="lines",
            name="Daily Growth Rate (%)",
            line=dict(color="#8c564b", width=1.8),
            hovertemplate="<b>Date</b>: %{x|%Y-%m-%d}<br><b>Growth</b>: %{y:.2f}%<extra></extra>",
        )
    )
    fig.update_layout(
        title=dict(text=title, font=dict(size=18)),
        xaxis_title="Date",
        yaxis_title="Daily Growth (%)",
        template="plotly_white",
        hovermode="x unified",
        margin=dict(l=40, r=40, t=60, b=40),
    )
    return fig


def plot_top_affected_countries_plotly(
    top_df: pd.DataFrame, metric: str = "confirmed", title: Optional[str] = None
) -> go.Figure:
    """Plots horizontal bar chart ranking top affected countries."""
    display_metric = metric.replace("_", " ").title()
    chart_title = title or f"Top {len(top_df)} Affected Countries by {display_metric}"

    # Sort so top country is on top in horizontal bar
    sorted_df = top_df.sort_values(by=metric, ascending=True)

    fig = px.bar(
        sorted_df,
        x=metric,
        y="country",
        orientation="h",
        text=metric,
        color=metric,
        color_continuous_scale="Reds" if metric == "deaths" else "Blues",
        title=chart_title,
    )
    fig.update_traces(
        texttemplate="%{text:,.0f}",
        textposition="outside",
        hovertemplate="<b>%{y}</b>: %{x:,.0f}<extra></extra>",
    )
    fig.update_layout(
        template="plotly_white",
        xaxis_title=display_metric,
        yaxis_title="Country",
        margin=dict(l=40, r=40, t=60, b=40),
    )
    return fig


# -----------------------------------------------------------------------------
# SEABORN & MATPLOTLIB CHARTS
# -----------------------------------------------------------------------------

def plot_correlation_heatmap_seaborn(
    df: pd.DataFrame, save_path: Optional[str] = None
) -> plt.Figure:
    """Creates and optionally saves a correlation heatmap using Seaborn."""
    corr_df = calculate_correlation_matrix(df)

    fig, ax = plt.subplots(figsize=(10, 8))
    sns.heatmap(
        corr_df,
        annot=True,
        fmt=".2f",
        cmap="coolwarm",
        square=True,
        cbar_kws={"shrink": 0.8},
        linewidths=0.5,
        ax=ax,
    )
    ax.set_title("COVID-19 Indicators Pearson Correlation Heatmap", fontsize=14, pad=15)
    plt.tight_layout()

    if save_path:
        out_path = Path(save_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out_path, dpi=300, bbox_inches="tight")
        print(f"[INFO] Correlation heatmap saved to {out_path.resolve()}")

    return fig


def export_all_eda_visualizations(
    df: pd.DataFrame, output_dir: str = "reports/figures"
) -> Dict[str, str]:
    """Generates and exports all EDA charts to disk.

    Parameters
    ----------
    df : pd.DataFrame
        Cleaned COVID-19 dataframe.
    output_dir : str
        Directory to save figures into.

    Returns
    -------
    dict
        Dictionary mapping chart names to their saved file paths.
    """
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    global_ts = get_global_time_series(df)
    top_countries = get_top_affected_countries(df, n=10, metric="confirmed")

    saved_files = {}

    # 1. Cases over time (Plotly HTML)
    f1 = plot_cases_over_time_plotly(global_ts)
    p1 = out_dir / "cases_over_time.html"
    f1.write_html(str(p1))
    saved_files["cases_over_time"] = str(p1)

    # 2. Daily cases + 7d / 14d MA (Plotly HTML)
    f2 = plot_daily_cases_and_ma_plotly(global_ts)
    p2 = out_dir / "daily_cases_ma.html"
    f2.write_html(str(p2))
    saved_files["daily_cases_ma"] = str(p2)

    # 3. Deaths over time (Plotly HTML)
    f3 = plot_deaths_over_time_plotly(global_ts)
    p3 = out_dir / "deaths_over_time.html"
    f3.write_html(str(p3))
    saved_files["deaths_over_time"] = str(p3)

    # 4. Recoveries over time (Plotly HTML)
    f4 = plot_recoveries_over_time_plotly(global_ts)
    p4 = out_dir / "recoveries_over_time.html"
    f4.write_html(str(p4))
    saved_files["recoveries_over_time"] = str(p4)

    # 5. Active cases (Plotly HTML)
    f5 = plot_active_cases_plotly(global_ts)
    p5 = out_dir / "active_cases.html"
    f5.write_html(str(p5))
    saved_files["active_cases"] = str(p5)

    # 6. Daily growth rate (Plotly HTML)
    f6 = plot_growth_rate_plotly(global_ts)
    p6 = out_dir / "daily_growth_rate.html"
    f6.write_html(str(p6))
    saved_files["daily_growth_rate"] = str(p6)

    # 7. Top 10 affected countries (Plotly HTML)
    f7 = plot_top_affected_countries_plotly(top_countries, metric="confirmed")
    p7 = out_dir / "top_countries.html"
    f7.write_html(str(p7))
    saved_files["top_countries"] = str(p7)

    # 8. Correlation heatmap (Seaborn PNG)
    p8 = out_dir / "correlation_heatmap.png"
    plot_correlation_heatmap_seaborn(df, save_path=str(p8))
    plt.close("all")
    saved_files["correlation_heatmap"] = str(p8)

    print(f"[INFO] Successfully exported {len(saved_files)} EDA visualizations to {out_dir.resolve()}")
    return saved_files


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("TESTING COVID-19 VISUALIZATION MODULE (visualization.py)")
    print("=" * 60)

    # Load and clean data
    raw_data = load_covid_data(verbose=False)
    cleaned_data = clean_covid_data(raw_data, verbose=False)

    # Test visualization export
    artifacts = export_all_eda_visualizations(cleaned_data, output_dir="reports/figures")

    print("\n--- Generated Visualization Artifacts ---")
    for name, path in artifacts.items():
        print(f"  - {name:<22}: {path}")

    print("\n[SUCCESS] visualization.py tested successfully without errors.\n")
