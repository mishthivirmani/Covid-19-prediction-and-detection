"""Data Loader Module for COVID-19 Prediction and Analysis Project.

This module loads the COVID-19 dataset from disk, verifies file existence,
handles basic loading errors, displays summary information, and returns
a pandas DataFrame.
"""

import os
from pathlib import Path
from typing import Optional
import pandas as pd


def load_covid_data(filepath: Optional[str] = None, verbose: bool = True) -> pd.DataFrame:
    """Loads the COVID-19 CSV dataset into a pandas DataFrame.

    Parameters
    ----------
    filepath : str, optional
        Path to the CSV dataset. Defaults to 'data/covid_data.csv' relative to
        the project root.
    verbose : bool, default=True
        Whether to print dataset summary information upon successful loading.

    Returns
    -------
    pd.DataFrame
        The loaded COVID-19 DataFrame.

    Raises
    ------
    FileNotFoundError
        If the specified dataset file does not exist.
    ValueError
        If the dataset is empty or invalid.
    RuntimeError
        If an unexpected error occurs while reading the CSV.
    """
    if filepath is None:
        # Default relative to this file's location or current working directory
        project_root = Path(__file__).resolve().parent.parent
        filepath = project_root / "data" / "covid_data.csv"
    else:
        filepath = Path(filepath)

    # 1. Check whether file exists
    if not filepath.exists():
        error_msg = f"Dataset file not found at: {filepath.resolve()}"
        raise FileNotFoundError(error_msg)

    # 2. Handle basic loading errors using pandas
    try:
        df = pd.read_csv(filepath)
    except pd.errors.EmptyDataError as exc:
        raise ValueError(f"The file at {filepath} is empty.") from exc
    except pd.errors.ParserError as exc:
        raise ValueError(f"Failed to parse CSV file at {filepath}.") from exc
    except Exception as exc:
        raise RuntimeError(f"An unexpected error occurred while loading {filepath}: {exc}") from exc

    # 3. Check for empty dataframe
    if df.empty:
        raise ValueError(f"The loaded dataset from {filepath} contains no rows.")

    # 4. Display useful dataset information if verbose is True
    if verbose:
        print("=" * 60)
        print("COVID-19 Dataset Loaded Successfully")
        print("=" * 60)
        print(f"File Source : {filepath.resolve()}")
        print(f"Dimensions  : {df.shape[0]} rows, {df.shape[1]} columns")
        print(f"Columns     : {list(df.columns)}")
        print("\nMissing Values per Column:")
        missing_counts = df.isnull().sum()
        for col, count in missing_counts.items():
            print(f"  - {col}: {count}")
        print("=" * 60)

    return df


if __name__ == "__main__":
    print("\n[TEST] Running data_loader.py verification test...\n")
    data = load_covid_data(verbose=True)

    print("\n--- Test Verification Outputs ---")
    print(f"1. Rows and Columns : {data.shape[0]} rows x {data.shape[1]} columns")
    print(f"2. Column Names     : {list(data.columns)}")
    print("\n3. First 5 Rows:")
    print(data.head())
    print("\n4. Missing-Value Counts:")
    print(data.isnull().sum())
    print("\n[SUCCESS] data_loader.py test completed successfully.")
