"""COVID-19 Exploratory Data Analysis (EDA) Module.

This module calculates descriptive statistics, aggregates time series data,
identifies peak dates, tracks top-affected regions, and provides correlation
matrices from the cleaned COVID-19 dataset.
"""

from typing import Dict, Any, Optional
import pandas as pd
import numpy as np

try:
    from src.data_loader import load_covid_data
    from src.data_cleaning import clean_covid_data
except ImportError:
    from data_loader import load_covid_data
    from data_cleaning import clean_covid_data


def get_global_time_series(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregates country-level data into a global chronological time series.

    Parameters
    ----------
    df : pd.DataFrame
        Cleaned COVID-19 dataset.

    Returns
    -------
    pd.DataFrame
        Daily aggregated global dataframe with moving averages and growth rate.
    """
    global_ts = (
        df.groupby("date")
        .agg(
            {
                "confirmed": "sum",
                "deaths": "sum",
                "recovered": "sum",
                "daily_cases": "sum",
                "daily_deaths": "sum",
                "daily_recoveries": "sum",
                "active_cases": "sum",
            }
        )
        .reset_index()
        .sort_values("date")
        .reset_index(drop=True)
    )

    # Compute global backward-looking moving averages
    global_ts["cases_7d_ma"] = global_ts["daily_cases"].rolling(window=7, min_periods=1).mean()
    global_ts["cases_14d_ma"] = global_ts["daily_cases"].rolling(window=14, min_periods=1).mean()
    global_ts["deaths_7d_ma"] = global_ts["daily_deaths"].rolling(window=7, min_periods=1).mean()

    # Compute global daily growth rate (percentage change)
    global_ts["daily_growth_rate"] = (
        global_ts["confirmed"]
        .pct_change()
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0.0)
        .clip(lower=0.0)
    )

    return global_ts


def calculate_global_summary_stats(df: pd.DataFrame) -> Dict[str, Any]:
    """Computes comprehensive global COVID-19 summary statistics.

    Parameters
    ----------
    df : pd.DataFrame
        Cleaned COVID-19 dataframe.

    Returns
    -------
    dict
        Dictionary of computed summary statistics.
    """
    latest_date = df["date"].max()
    latest_slice = df[df["date"] == latest_date]

    total_confirmed = int(latest_slice["confirmed"].sum())
    total_deaths = int(latest_slice["deaths"].sum())
    current_active = int(latest_slice["active_cases"].sum())

    # Johns Hopkins CSSE stopped tracking recovered counts globally in August 2021
    # We record both peak historical recorded recoveries and the latest recorded count
    peak_recovered = int(df.groupby("date")["recovered"].sum().max())
    latest_recovered = int(latest_slice["recovered"].sum())

    global_ts = get_global_time_series(df)

    # Maximum daily new cases and date
    max_daily_cases_idx = global_ts["daily_cases"].idxmax()
    max_daily_cases = int(global_ts.loc[max_daily_cases_idx, "daily_cases"])
    peak_case_date = str(global_ts.loc[max_daily_cases_idx, "date"].date())

    # Maximum daily deaths and date
    max_daily_deaths_idx = global_ts["daily_deaths"].idxmax()
    max_daily_deaths = int(global_ts.loc[max_daily_deaths_idx, "daily_deaths"])
    peak_death_date = str(global_ts.loc[max_daily_deaths_idx, "date"].date())

    # Average daily cases across entire timeline
    avg_daily_cases = float(global_ts["daily_cases"].mean())
    avg_daily_deaths = float(global_ts["daily_deaths"].mean())

    # Case fatality rate (% of confirmed cases that resulted in death)
    case_fatality_rate = (total_deaths / total_confirmed * 100) if total_confirmed > 0 else 0.0

    return {
        "latest_date": str(latest_date.date()),
        "total_confirmed": total_confirmed,
        "total_deaths": total_deaths,
        "peak_recorded_recoveries": peak_recovered,
        "latest_recorded_recoveries": latest_recovered,
        "active_cases": current_active,
        "max_daily_cases": max_daily_cases,
        "peak_case_date": peak_case_date,
        "max_daily_deaths": max_daily_deaths,
        "peak_death_date": peak_death_date,
        "avg_daily_cases": round(avg_daily_cases, 2),
        "avg_daily_deaths": round(avg_daily_deaths, 2),
        "case_fatality_rate_pct": round(case_fatality_rate, 2),
    }


def get_top_affected_countries(
    df: pd.DataFrame, n: int = 10, metric: str = "confirmed"
) -> pd.DataFrame:
    """Retrieves top N affected countries ranked by a specified metric.

    Parameters
    ----------
    df : pd.DataFrame
        Cleaned COVID-19 dataset.
    n : int, default=10
        Number of top countries to return.
    metric : str, default='confirmed'
        Metric to rank by ('confirmed', 'deaths', or 'active_cases').

    Returns
    -------
    pd.DataFrame
        Sorted ranking table of top countries.
    """
    latest_date = df["date"].max()
    latest_slice = df[df["date"] == latest_date]

    if metric not in latest_slice.columns:
        raise ValueError(f"Metric '{metric}' not found in dataset columns.")

    cols_to_agg = list(dict.fromkeys([metric, "confirmed", "deaths", "active_cases"]))
    ranked = (
        latest_slice.groupby("country")[cols_to_agg]
        .sum()
        .sort_values(by=metric, ascending=False)
        .head(n)
        .reset_index()
    )
    ranked["fatality_rate_pct"] = (ranked["deaths"] / ranked["confirmed"] * 100).round(2)
    return ranked


def get_country_summary(df: pd.DataFrame, country_name: str) -> Optional[Dict[str, Any]]:
    """Generates detailed epidemiological summary for a single country.

    Parameters
    ----------
    df : pd.DataFrame
        Cleaned COVID-19 dataset.
    country_name : str
        Country name as formatted in the dataset.

    Returns
    -------
    dict or None
        Summary statistics dictionary or None if country not found.
    """
    c_df = df[df["country"].str.lower() == country_name.lower()].sort_values("date").reset_index(drop=True)
    if c_df.empty:
        return None

    actual_name = c_df["country"].iloc[0]
    latest_row = c_df.iloc[-1]

    max_daily_cases_idx = c_df["daily_cases"].idxmax()
    max_daily_deaths_idx = c_df["daily_deaths"].idxmax()

    return {
        "country": actual_name,
        "latest_date": str(latest_row["date"].date()),
        "total_confirmed": int(latest_row["confirmed"]),
        "total_deaths": int(latest_row["deaths"]),
        "total_recovered": int(latest_row["recovered"]),
        "active_cases": int(latest_row["active_cases"]),
        "max_daily_cases": int(c_df.loc[max_daily_cases_idx, "daily_cases"]),
        "peak_case_date": str(c_df.loc[max_daily_cases_idx, "date"].date()),
        "max_daily_deaths": int(c_df.loc[max_daily_deaths_idx, "daily_deaths"]),
        "peak_death_date": str(c_df.loc[max_daily_deaths_idx, "date"].date()),
        "avg_daily_cases": round(float(c_df["daily_cases"].mean()), 2),
        "case_fatality_rate_pct": round((latest_row["deaths"] / latest_row["confirmed"] * 100) if latest_row["confirmed"] > 0 else 0.0, 2),
    }


def calculate_correlation_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """Calculates Pearson correlation between numeric epidemiological indicators.

    Parameters
    ----------
    df : pd.DataFrame
        Cleaned dataset.

    Returns
    -------
    pd.DataFrame
        Correlation matrix.
    """
    cols = [
        "confirmed",
        "deaths",
        "recovered",
        "daily_cases",
        "daily_deaths",
        "active_cases",
        "cases_7d_ma",
        "cases_14d_ma",
        "daily_growth_rate",
    ]
    available_cols = [c for c in cols if c in df.columns]
    return df[available_cols].corr()


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("RUNNING COVID-19 EXPLORATORY DATA ANALYSIS (analysis.py)")
    print("=" * 60)

    # 1. Load and clean data
    raw_df = load_covid_data(verbose=False)
    clean_df = clean_covid_data(raw_df, verbose=False)

    # 2. Global summary
    stats = calculate_global_summary_stats(clean_df)
    print("\n--- Global Summary Statistics ---")
    for key, value in stats.items():
        print(f"  {key:<28}: {value}")

    # 3. Top affected countries
    top_10 = get_top_affected_countries(clean_df, n=10, metric="confirmed")
    print("\n--- Top 10 Affected Countries (by Confirmed Cases) ---")
    print(top_10[["country", "confirmed", "deaths", "fatality_rate_pct"]].to_string(index=False))

    # 4. Correlation Matrix
    corr = calculate_correlation_matrix(clean_df)
    print("\n--- Correlation Matrix (Selected Indicators) ---")
    print(corr[["confirmed", "deaths", "daily_cases", "cases_7d_ma"]].round(3))
    print("\n[SUCCESS] analysis.py completed successfully.\n")
