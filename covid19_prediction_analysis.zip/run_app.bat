@echo off
title COVID-19 Prediction & Analysis Dashboard
cd /d "%~dp0"
echo ========================================================
echo Starting COVID-19 Prediction & Analysis Dashboard...
echo ========================================================
echo.
echo Activating virtual environment and launching Streamlit...
echo.
call .venv\Scripts\activate.bat
streamlit run app.py
pause
