"""COVID-19 Time-Series Feature Engineering and Prediction Module.

Implements lag-based feature engineering, chronological train/test splitting,
model training, evaluation (MAE, RMSE, R2), and multi-step forecasting.
"""

from pathlib import Path
from typing import Dict, Any, Tuple, List, Optional
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, root_mean_squared_error, r2_score
import joblib

try:
    from src.data_loader import load_covid_data
    from src.data_cleaning import clean_covid_data
    from src.analysis import get_global_time_series
except ImportError:
    from data_loader import load_covid_data
    from data_cleaning import clean_covid_data
    from analysis import get_global_time_series


def create_time_series_features(
    ts_df: pd.DataFrame,
    target_col: str = "daily_cases",
    lags: List[int] = (1, 2, 3, 7, 14),
    rolling_windows: List[int] = (7, 14),
) -> Tuple[pd.DataFrame, List[str]]:
    """Generates lag and historical rolling features strictly avoiding lookahead data leakage.

    Parameters
    ----------
    ts_df : pd.DataFrame
        Chronologically sorted time series dataframe containing 'date' and target_col.
    target_col : str, default='daily_cases'
        The target column to forecast.
    lags : list of int
        Days to lag historical observations.
    rolling_windows : list of int
        Historical rolling window sizes.

    Returns
    -------
    tuple
        (featured_df, feature_column_names)
    """
    df = ts_df.copy()
    if "date" in df.columns:
        df = df.sort_values("date").reset_index(drop=True)

    feature_cols = []

    # 1. Historical Lag Features
    # Shifted backward so day t uses historical values t-k
    for lag in lags:
        col_name = f"cases_lag_{lag}"
        df[col_name] = df[target_col].shift(lag)
        feature_cols.append(col_name)

    # 2. Historical Rolling Averages & Standard Deviations
    # Shift by 1 first so rolling calculations DO NOT include current day t's target
    shifted_target = df[target_col].shift(1)
    for window in rolling_windows:
        mean_col = f"cases_rolling_mean_{window}"
        std_col = f"cases_rolling_std_{window}"
        df[mean_col] = shifted_target.rolling(window=window).mean()
        df[std_col] = shifted_target.rolling(window=window).std()
        feature_cols.extend([mean_col, std_col])

    # 3. Calendar Features (Known in advance without leakage)
    if "date" in df.columns:
        df["day_of_week"] = df["date"].dt.dayofweek
        df["day_of_year"] = df["date"].dt.dayofyear
        feature_cols.extend(["day_of_week", "day_of_year"])

    # Drop initial rows where lag values are NaN
    max_lag = max(max(lags), max(rolling_windows))
    clean_featured_df = df.dropna(subset=feature_cols).reset_index(drop=True)

    return clean_featured_df, feature_cols


def chronological_train_test_split(
    df: pd.DataFrame, feature_cols: List[str], target_col: str = "daily_cases", train_ratio: float = 0.8
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series, pd.Series, pd.Series]:
    """Splits time series data chronologically without shuffling to avoid data leakage."""
    split_idx = int(len(df) * train_ratio)

    X_train = df.iloc[:split_idx][feature_cols]
    X_test = df.iloc[split_idx:][feature_cols]

    y_train = df.iloc[:split_idx][target_col]
    y_test = df.iloc[split_idx:][target_col]

    dates_train = df.iloc[:split_idx]["date"] if "date" in df.columns else None
    dates_test = df.iloc[split_idx:]["date"] if "date" in df.columns else None

    return X_train, X_test, y_train, y_test, dates_train, dates_test


def evaluate_models(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    y_test: pd.Series,
    random_state: int = 42,
) -> Tuple[Dict[str, Any], pd.DataFrame]:
    """Trains and evaluates Linear Regression, Random Forest, and Gradient Boosting models.

    Parameters
    ----------
    X_train, y_train : pd.DataFrame, pd.Series
        Training predictors and targets.
    X_test, y_test : pd.DataFrame, pd.Series
        Testing predictors and targets.
    random_state : int, default=42
        Reproducibility seed.

    Returns
    -------
    tuple
        (results_dict, comparison_dataframe)
    """
    candidate_models = {
        "Linear Regression": LinearRegression(),
        "Random Forest Regressor": RandomForestRegressor(n_estimators=100, random_state=random_state),
        "Gradient Boosting Regressor": GradientBoostingRegressor(n_estimators=100, random_state=random_state),
    }

    results = {}
    table_rows = []

    for name, model in candidate_models.items():
        # Train
        model.fit(X_train, y_train)

        # Test set predictions
        y_pred = model.predict(X_test)
        # Ensure non-negative predicted case counts
        y_pred = np.clip(y_pred, 0, None)

        mae = mean_absolute_error(y_test, y_pred)
        rmse = root_mean_squared_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)

        results[name] = {
            "model": model,
            "predictions": y_pred,
            "mae": mae,
            "rmse": rmse,
            "r2": r2,
        }

        table_rows.append(
            {
                "Model": name,
                "MAE": mae,
                "RMSE": rmse,
                "R² Score": r2,
            }
        )

    comparison_df = pd.DataFrame(table_rows).sort_values(by="RMSE", ascending=True).reset_index(drop=True)
    return results, comparison_df


def forecast_future_days(
    model: Any,
    latest_ts_slice: pd.DataFrame,
    feature_cols: List[str],
    days: int = 7,
) -> pd.DataFrame:
    """Recursively forecasts future daily COVID-19 cases for N days ahead.

    Parameters
    ----------
    model : trained regressor
        Fitted machine learning model.
    latest_ts_slice : pd.DataFrame
        Recent historical dataframe with at least 30 past consecutive days.
    feature_cols : list of str
        Features expected by the model.
    days : int, default=7
        Number of future days to forecast.

    Returns
    -------
    pd.DataFrame
        Forecasted dates and predicted cases.
    """
    history = latest_ts_slice[["date", "daily_cases"]].copy().sort_values("date").reset_index(drop=True)

    future_predictions = []
    last_date = history["date"].max()

    for step in range(1, days + 1):
        target_date = last_date + pd.Timedelta(days=step)

        # Build feature vector from current history
        row_feat = {}
        for lag in [1, 2, 3, 7, 14]:
            if lag <= len(history):
                row_feat[f"cases_lag_{lag}"] = history["daily_cases"].iloc[-lag]
            else:
                row_feat[f"cases_lag_{lag}"] = history["daily_cases"].mean()

        for window in [7, 14]:
            past_window = history["daily_cases"].iloc[-window:]
            row_feat[f"cases_rolling_mean_{window}"] = past_window.mean()
            row_feat[f"cases_rolling_std_{window}"] = past_window.std() if len(past_window) > 1 else 0.0

        row_feat["day_of_week"] = target_date.dayofweek
        row_feat["day_of_year"] = target_date.dayofyear

        feat_vector = pd.DataFrame([row_feat])[feature_cols].fillna(0)
        pred_val = float(np.clip(model.predict(feat_vector)[0], 0, None))

        future_predictions.append({"date": target_date, "predicted_cases": pred_val})

        # Append prediction to history to allow recursive forecasting
        new_row = pd.DataFrame([{"date": target_date, "daily_cases": pred_val}])
        history = pd.concat([history, new_row], ignore_index=True)

    return pd.DataFrame(future_predictions)
