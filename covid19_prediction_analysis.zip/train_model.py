"""COVID-19 Model Training and Evaluation Pipeline.

Trains and evaluates Linear Regression, Random Forest, and Gradient Boosting
models on time-series data using chronological splitting and lag features.
Saves the best-performing model artifact, configuration, and visualization.
"""

from pathlib import Path
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import joblib
import pandas as pd

from src.data_loader import load_covid_data
from src.data_cleaning import clean_covid_data
from src.analysis import get_global_time_series
from src.prediction import (
    create_time_series_features,
    chronological_train_test_split,
    evaluate_models,
)


def run_training_pipeline() -> dict:
    """Executes end-to-end model training, evaluation, saving, and plotting."""
    print("=" * 70)
    print("COVID-19 MACHINE LEARNING TRAINING & EVALUATION PIPELINE")
    print("=" * 70)

    # 1. Load and Clean Dataset
    print("\n[1/6] Loading and cleaning dataset...")
    raw_df = load_covid_data(verbose=False)
    cleaned_df = clean_covid_data(raw_df, verbose=False)
    global_ts = get_global_time_series(cleaned_df)
    print(f"       Global time-series days available: {len(global_ts)} days")

    # 2. Feature Engineering (Lags and Rolling Statistics)
    print("\n[2/6] Generating time-series features (lags + rolling averages)...")
    featured_df, feature_cols = create_time_series_features(
        global_ts,
        target_col="daily_cases",
        lags=[1, 2, 3, 7, 14],
        rolling_windows=[7, 14],
    )
    print(f"       Features created ({len(feature_cols)}): {feature_cols}")
    print(f"       Clean sample rows after lag truncation: {len(featured_df)}")

    # 3. Chronological Train-Test Split (No Shuffling to Prevent Leakage)
    print("\n[3/6] Splitting data chronologically (80% train / 20% test)...")
    X_train, X_test, y_train, y_test, dates_train, dates_test = chronological_train_test_split(
        featured_df, feature_cols, target_col="daily_cases", train_ratio=0.8
    )
    print(f"       Training Set : {len(X_train)} samples ({dates_train.min().date()} to {dates_train.max().date()})")
    print(f"       Testing Set  : {len(X_test)} samples ({dates_test.min().date()} to {dates_test.max().date()})")

    # 4. Train and Evaluate Models
    print("\n[4/6] Training and evaluating candidate regressors...")
    results, comparison_df = evaluate_models(X_train, y_train, X_test, y_test, random_state=42)

    print("\n" + "-" * 70)
    print("MODEL EVALUATION COMPARISON TABLE (ON UNSEEN TEST DATA)")
    print("-" * 70)
    formatted_table = comparison_df.copy()
    formatted_table["MAE"] = formatted_table["MAE"].apply(lambda v: f"{v:,.1f}")
    formatted_table["RMSE"] = formatted_table["RMSE"].apply(lambda v: f"{v:,.1f}")
    formatted_table["R² Score"] = formatted_table["R² Score"].apply(lambda v: f"{v:.4f}")
    print(formatted_table.to_string(index=False))
    print("-" * 70)

    # 5. Select and Save Best Model
    best_model_name = comparison_df.iloc[0]["Model"]
    best_model_obj = results[best_model_name]["model"]
    print(f"\n[5/6] Best Model Selected: '{best_model_name}' (Lowest RMSE / Highest R²)")

    models_dir = Path("models")
    models_dir.mkdir(parents=True, exist_ok=True)

    # Save to requested destination: models/covidpredictionmodel.pkl
    model_path_1 = models_dir / "covidpredictionmodel.pkl"
    model_path_2 = models_dir / "covid_prediction_model.pkl"
    joblib.dump(best_model_obj, model_path_1)
    joblib.dump(best_model_obj, model_path_2)
    print(f"       Model saved to: {model_path_1.resolve()}")

    # Save feature configuration and metadata for reproducible inference
    config = {
        "best_model": best_model_name,
        "feature_columns": feature_cols,
        "lags": [1, 2, 3, 7, 14],
        "rolling_windows": [7, 14],
        "target_column": "daily_cases",
        "train_date_range": [str(dates_train.min().date()), str(dates_train.max().date())],
        "test_date_range": [str(dates_test.min().date()), str(dates_test.max().date())],
        "metrics": {
            "MAE": float(comparison_df.iloc[0]["MAE"]),
            "RMSE": float(comparison_df.iloc[0]["RMSE"]),
            "R2": float(comparison_df.iloc[0]["R² Score"]),
        },
    }
    config_path = models_dir / "feature_config.json"
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4)
    print(f"       Feature config saved to: {config_path.resolve()}")

    # 6. Actual vs Predicted Visualizations
    print("\n[6/6] Generating Actual vs Predicted visualizations...")
    figures_dir = Path("reports/figures")
    figures_dir.mkdir(parents=True, exist_ok=True)

    # Interactive Plotly Chart
    fig_plotly = go.Figure()
    fig_plotly.add_trace(
        go.Scatter(
            x=dates_test,
            y=y_test,
            mode="lines",
            name="Actual Daily Cases",
            line=dict(color="#1f77b4", width=2.5),
        )
    )

    colors = {
        "Linear Regression": "#2ca02c",
        "Random Forest Regressor": "#ff7f0e",
        "Gradient Boosting Regressor": "#9467bd",
    }

    for name, res in results.items():
        is_best = (name == best_model_name)
        fig_plotly.add_trace(
            go.Scatter(
                x=dates_test,
                y=res["predictions"],
                mode="lines",
                name=f"{name} {'(Best)' if is_best else ''}",
                line=dict(
                    color=colors.get(name, "#7f7f7f"),
                    width=2.5 if is_best else 1.5,
                    dash="solid" if is_best else "dash",
                ),
            )
        )

    fig_plotly.update_layout(
        title="COVID-19 Daily Cases: Actual vs Model Predictions (Test Set)",
        xaxis_title="Date",
        yaxis_title="Daily Cases",
        template="plotly_white",
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    )
    plotly_html = figures_dir / "actual_vs_predicted.html"
    fig_plotly.write_html(str(plotly_html))
    print(f"       Interactive plot saved to: {plotly_html.resolve()}")

    # Static Matplotlib/Seaborn Chart
    fig_plt, ax = plt.subplots(figsize=(12, 6))
    ax.plot(dates_test, y_test, label="Actual Daily Cases", color="#1f77b4", linewidth=2.5)
    for name, res in results.items():
        is_best = (name == best_model_name)
        ax.plot(
            dates_test,
            res["predictions"],
            label=f"{name} {'[Best]' if is_best else ''}",
            linestyle="-" if is_best else "--",
            linewidth=2.2 if is_best else 1.4,
            color=colors.get(name, "#7f7f7f"),
        )
    ax.set_title("COVID-19 Daily Cases: Actual vs Predicted (Chronological Test Set)", fontsize=14, pad=12)
    ax.set_xlabel("Date", fontsize=12)
    ax.set_ylabel("Daily Cases", fontsize=12)
    ax.legend(loc="upper left")
    ax.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()

    static_png = figures_dir / "actual_vs_predicted.png"
    fig_plt.savefig(static_png, dpi=300, bbox_inches="tight")
    plt.close("all")
    print(f"       Static figure saved to: {static_png.resolve()}")

    print("\n[SUCCESS] Model training and evaluation completed successfully.\n")

    return {
        "comparison_table": comparison_df,
        "best_model": best_model_name,
        "config": config,
    }


if __name__ == "__main__":
    run_training_pipeline()
