"""Streamlit Web Application for COVID-19 Prediction and Analysis.

Provides an interactive college project dashboard featuring:
- Global and country-level KPI tracking
- Exploratory data visualization (Plotly & Seaborn)
- Time-series forecasting using trained Machine Learning models
- Comprehensive model benchmark comparison (MAE, RMSE, R2)
- Dataset inspection and custom CSV upload support
"""

import sys
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.data_loader import load_covid_data
from src.data_cleaning import clean_covid_data
from src.analysis import (
    get_global_time_series,
    calculate_global_summary_stats,
    get_top_affected_countries,
    get_country_summary,
    calculate_correlation_matrix,
)
from src.prediction import (
    create_time_series_features,
    forecast_future_days,
)

# -----------------------------------------------------------------------------
# PAGE CONFIGURATION & STYLING
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="COVID-19 Prediction & Analysis",
    page_icon="🦠",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .main-title {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1E3A8A;
        margin-bottom: 0.2rem;
    }
    .sub-title {
        font-size: 1.05rem;
        color: #4B5563;
        margin-bottom: 1.5rem;
    }
    .kpi-card {
        background: linear-gradient(135deg, #F8FAFC 0%, #EFF6FF 100%);
        border: 1px solid #E2E8F0;
        border-radius: 12px;
        padding: 1.2rem 1rem;
        text-align: center;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .kpi-title {
        font-size: 0.85rem;
        font-weight: 600;
        text-transform: uppercase;
        color: #64748B;
        letter-spacing: 0.05em;
        margin-bottom: 0.4rem;
    }
    .kpi-value {
        font-size: 1.8rem;
        font-weight: 800;
        color: #0F172A;
    }
    .kpi-sub {
        font-size: 0.75rem;
        color: #94A3B8;
        margin-top: 0.2rem;
    }
    .badge-best {
        background-color: #10B981;
        color: white;
        padding: 0.2rem 0.6rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        display: inline-block;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# -----------------------------------------------------------------------------
# DATA CACHING & HELPERS
# -----------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def get_cached_dataset() -> pd.DataFrame:
    """Loads and cleans the default project COVID-19 dataset with caching."""
    raw = load_covid_data(verbose=False)
    return clean_covid_data(raw, verbose=False)


@st.cache_resource(show_spinner=False)
def load_trained_model_and_config():
    """Loads serialized model and feature metadata."""
    model_path = PROJECT_ROOT / "models" / "covidpredictionmodel.pkl"
    config_path = PROJECT_ROOT / "models" / "feature_config.json"

    model = None
    config = None

    if model_path.exists():
        try:
            model = joblib.load(model_path)
        except Exception:
            model = None

    if config_path.exists():
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
        except Exception:
            config = None

    return model, config


# -----------------------------------------------------------------------------
# SIDEBAR NAVIGATION & PROJECT METADATA
# -----------------------------------------------------------------------------
st.sidebar.markdown("## 🦠 COVID-19 Analytics")
st.sidebar.markdown("**College Project Demonstration**")
st.sidebar.caption("Prediction and Analysis Using Machine Learning")
st.sidebar.divider()

nav_selection = st.sidebar.radio(
    "Navigation Menu",
    [
        "📊 Dashboard",
        "📈 Data Analysis",
        "🔮 Prediction",
        "🏆 Model Performance",
        "📁 Dataset",
    ],
    index=0,
)

st.sidebar.divider()

with st.sidebar.expander("ℹ️ About This Project", expanded=False):
    st.markdown(
        r"""
        **Title:** COVID-19 Prediction and Analysis
        
        **Technologies:** Python, Scikit-Learn, Streamlit, Plotly, Pandas
        
        **Source:** Johns Hopkins University CSSE (198 countries, Jan 2020 – Apr 2022)
        
        **Methodology:** Leak-free lag engineering ($t-1 \dots t-14$), rolling averages, and chronological validation.
        """
    )

st.sidebar.warning(
    "⚠️ **Disclaimer:** For educational & academic research demonstration only. Not clinically validated or medical advice."
)

st.sidebar.caption("Antigravity ML Framework | Python 3.13")


# -----------------------------------------------------------------------------
# 1. DASHBOARD SECTION
# -----------------------------------------------------------------------------
if nav_selection == "📊 Dashboard":
    st.markdown('<div class="main-title">COVID-19 Global Overview Dashboard</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">Epidemiological monitoring, key performance indicators, and pandemic trajectories.</div>',
        unsafe_allow_html=True,
    )

    # Project Description Banner
    st.info(
        "🎓 **Academic Project Overview:** This college data science platform investigates international COVID-19 infection trends and evaluates time-series machine learning models to forecast short-term caseloads using leak-free historical lags."
    )

    # Prominent Medical Disclaimer Box
    st.markdown(
        """
        <div style="background-color: #FEF3C7; border-left: 5px solid #F59E0B; padding: 0.9rem 1.2rem; border-radius: 6px; margin-bottom: 1.5rem;">
            <strong style="color: #92400E; font-size: 0.95rem;">⚠️ Medical & Public Health Disclaimer</strong>
            <p style="color: #78350F; font-size: 0.85rem; margin: 0.3rem 0 0 0; line-height: 1.4;">
                This system is developed strictly for <strong>academic research and computational demonstration</strong>. 
                Predictions are mathematical approximations based on historical reporting data and <strong>must NOT be used as medical advice, clinical diagnostics, treatment guidelines, or public health policy directives</strong>.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    try:
        df = get_cached_dataset()
        stats = calculate_global_summary_stats(df)
        global_ts = get_global_time_series(df)
        latest_daily_cases = int(global_ts.iloc[-1]["daily_cases"])

        # KPI Cards (5 Cards)
        col1, col2, col3, col4, col5 = st.columns(5)
        with col1:
            st.markdown(
                f"""
                <div class="kpi-card">
                    <div class="kpi-title">Total Confirmed</div>
                    <div class="kpi-value">{stats['total_confirmed']:,}</div>
                    <div class="kpi-sub">As of {stats['latest_date']}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        with col2:
            st.markdown(
                f"""
                <div class="kpi-card">
                    <div class="kpi-title">Total Deaths</div>
                    <div class="kpi-value" style="color: #DC2626;">{stats['total_deaths']:,}</div>
                    <div class="kpi-sub">Fatality Rate: {stats['case_fatality_rate_pct']}%</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        with col3:
            st.markdown(
                f"""
                <div class="kpi-card">
                    <div class="kpi-title">Peak Recoveries</div>
                    <div class="kpi-value" style="color: #10B981;">{stats['peak_recorded_recoveries']:,}</div>
                    <div class="kpi-sub">Historical Peak (Aug 2021)*</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        with col4:
            st.markdown(
                f"""
                <div class="kpi-card">
                    <div class="kpi-title">Active Cases</div>
                    <div class="kpi-value" style="color: #7C3AED;">{stats['active_cases']:,}</div>
                    <div class="kpi-sub">Estimated global caseload</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        with col5:
            st.markdown(
                f"""
                <div class="kpi-card">
                    <div class="kpi-title">Latest Daily Cases</div>
                    <div class="kpi-value" style="color: #2563EB;">{latest_daily_cases:,}</div>
                    <div class="kpi-sub">7-Day MA: {int(global_ts.iloc[-1]['cases_7d_ma']):,}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

        st.caption("*Note: Johns Hopkins University stopped collecting global recovery metrics in August 2021 as international health ministries shifted tracking policies.")

        st.markdown("---")

        # Two Main Dashboard Visualizations
        d_col1, d_col2 = st.columns([3, 2])

        with d_col1:
            st.markdown("#### Global Transmission Trajectory")
            fig_dash = go.Figure()
            fig_dash.add_trace(
                go.Scatter(
                    x=global_ts["date"],
                    y=global_ts["confirmed"],
                    mode="lines",
                    name="Confirmed Cases",
                    line=dict(color="#1E3A8A", width=2.5),
                )
            )
            fig_dash.add_trace(
                go.Scatter(
                    x=global_ts["date"],
                    y=global_ts["deaths"],
                    mode="lines",
                    name="Deaths",
                    line=dict(color="#DC2626", width=2),
                )
            )
            fig_dash.update_layout(
                template="plotly_white",
                margin=dict(l=20, r=20, t=30, b=20),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                xaxis_title="Date",
                yaxis_title="Cumulative Count",
            )
            st.plotly_chart(fig_dash, use_container_width=True)

        with d_col2:
            st.markdown("#### Top 5 Most Affected Countries")
            top_5 = get_top_affected_countries(df, n=5, metric="confirmed")
            fig_top5 = px.bar(
                top_5.sort_values(by="confirmed", ascending=True),
                x="confirmed",
                y="country",
                orientation="h",
                text="confirmed",
                color="confirmed",
                color_continuous_scale="Blues",
            )
            fig_top5.update_traces(texttemplate="%{text:,.0f}", textposition="outside")
            fig_top5.update_layout(
                template="plotly_white",
                margin=dict(l=20, r=20, t=30, b=20),
                xaxis_title="Confirmed Cases",
                yaxis_title="",
                coloraxis_showscale=False,
            )
            st.plotly_chart(fig_top5, use_container_width=True)

    except Exception as e:
        st.error(f"Unable to render dashboard metrics: {e}")


# -----------------------------------------------------------------------------
# 2. DATA ANALYSIS SECTION
# -----------------------------------------------------------------------------
elif nav_selection == "📈 Data Analysis":
    st.markdown('<div class="main-title">Exploratory Data Analysis</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">Explore pandemic curves, daily new infections, moving averages, and regional comparisons.</div>',
        unsafe_allow_html=True,
    )

    try:
        df = get_cached_dataset()
        country_list = ["Global"] + sorted(list(df["country"].unique()))

        c_filter_col1, c_filter_col2 = st.columns([1, 2])
        with c_filter_col1:
            selected_region = st.selectbox("Select Country / Region:", country_list, index=0)

        # Build region-specific time series
        if selected_region == "Global":
            ts_data = get_global_time_series(df)
            region_title = "Global"
        else:
            region_df = df[df["country"] == selected_region].sort_values("date").reset_index(drop=True)
            ts_data = region_df.copy()
            region_title = selected_region

        with c_filter_col2:
            st.info(f"Showing chronological time series for **{region_title}** ({len(ts_data)} daily records from {ts_data['date'].min().date()} to {ts_data['date'].max().date()}).")

        st.markdown("---")

        # Row 1: Cumulative Cases & Daily Cases + Moving Averages
        r1_c1, r1_c2 = st.columns(2)

        with r1_c1:
            st.markdown(f"#### Cumulative Cases Over Time ({region_title})")
            fig1 = go.Figure()
            fig1.add_trace(
                go.Scatter(
                    x=ts_data["date"],
                    y=ts_data["confirmed"],
                    mode="lines",
                    name="Confirmed",
                    line=dict(color="#2563EB", width=2.5),
                )
            )
            fig1.update_layout(template="plotly_white", margin=dict(l=20, r=20, t=30, b=20), xaxis_title="Date", yaxis_title="Cases")
            st.plotly_chart(fig1, use_container_width=True)

        with r1_c2:
            st.markdown(f"#### Daily Cases & Moving Averages ({region_title})")
            fig2 = go.Figure()
            fig2.add_trace(
                go.Bar(
                    x=ts_data["date"],
                    y=ts_data["daily_cases"],
                    name="Daily Cases",
                    marker=dict(color="rgba(37, 99, 235, 0.4)"),
                )
            )
            fig2.add_trace(
                go.Scatter(
                    x=ts_data["date"],
                    y=ts_data["cases_7d_ma"],
                    mode="lines",
                    name="7-Day Moving Avg",
                    line=dict(color="#F97316", width=2.5),
                )
            )
            if "cases_14d_ma" in ts_data.columns:
                fig2.add_trace(
                    go.Scatter(
                        x=ts_data["date"],
                        y=ts_data["cases_14d_ma"],
                        mode="lines",
                        name="14-Day Moving Avg",
                        line=dict(color="#10B981", width=2.0, dash="dash"),
                    )
                )
            fig2.update_layout(
                template="plotly_white",
                margin=dict(l=20, r=20, t=30, b=20),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                xaxis_title="Date",
                yaxis_title="Cases",
            )
            st.plotly_chart(fig2, use_container_width=True)

        # Row 2: Deaths & Recoveries
        r2_c1, r2_c2 = st.columns(2)

        with r2_c1:
            st.markdown(f"#### Mortality Trajectory ({region_title})")
            fig3 = make_subplots(specs=[[{"secondary_y": True}]])
            fig3.add_trace(
                go.Bar(
                    x=ts_data["date"],
                    y=ts_data["daily_deaths"],
                    name="Daily Deaths",
                    marker=dict(color="rgba(220, 38, 38, 0.4)"),
                ),
                secondary_y=False,
            )
            fig3.add_trace(
                go.Scatter(
                    x=ts_data["date"],
                    y=ts_data["deaths"],
                    mode="lines",
                    name="Cumulative Deaths",
                    line=dict(color="#DC2626", width=2.5),
                ),
                secondary_y=True,
            )
            fig3.update_layout(
                template="plotly_white",
                margin=dict(l=20, r=20, t=30, b=20),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                xaxis_title="Date",
            )
            fig3.update_yaxes(title_text="Daily Deaths", secondary_y=False)
            fig3.update_yaxes(title_text="Cumulative Deaths", secondary_y=True)
            st.plotly_chart(fig3, use_container_width=True)

        with r2_c2:
            st.markdown(f"#### Recoveries Over Time ({region_title})")
            fig4 = go.Figure()
            fig4.add_trace(
                go.Scatter(
                    x=ts_data["date"],
                    y=ts_data["recovered"],
                    mode="lines",
                    name="Recovered",
                    line=dict(color="#10B981", width=2.5),
                )
            )
            fig4.update_layout(
                template="plotly_white",
                margin=dict(l=20, r=20, t=30, b=20),
                xaxis_title="Date",
                yaxis_title="Recorded Recoveries",
            )
            st.plotly_chart(fig4, use_container_width=True)

        # Row 3: Active Cases & Regional Ranking (or Growth Rate)
        r3_c1, r3_c2 = st.columns(2)

        with r3_c1:
            st.markdown(f"#### Estimated Active Cases ({region_title})")
            fig5 = go.Figure()
            fig5.add_trace(
                go.Scatter(
                    x=ts_data["date"],
                    y=ts_data["active_cases"],
                    mode="lines",
                    name="Active Cases",
                    line=dict(color="#7C3AED", width=2.2),
                    fill="tozeroy",
                    fillcolor="rgba(124, 58, 237, 0.15)",
                )
            )
            fig5.update_layout(template="plotly_white", margin=dict(l=20, r=20, t=30, b=20), xaxis_title="Date", yaxis_title="Active Cases")
            st.plotly_chart(fig5, use_container_width=True)

        with r3_c2:
            st.markdown(f"#### Daily Growth Rate (%) ({region_title})")
            fig6 = go.Figure()
            growth_pct = ts_data["daily_growth_rate"] * 100
            fig6.add_trace(
                go.Scatter(
                    x=ts_data["date"],
                    y=growth_pct,
                    mode="lines",
                    name="Growth Rate %",
                    line=dict(color="#D97706", width=1.8),
                )
            )
            fig6.update_layout(template="plotly_white", margin=dict(l=20, r=20, t=30, b=20), xaxis_title="Date", yaxis_title="Daily Growth (%)")
            st.plotly_chart(fig6, use_container_width=True)

    except Exception as e:
        st.error(f"Error executing data analysis: {e}")


# -----------------------------------------------------------------------------
# 3. PREDICTION SECTION
# -----------------------------------------------------------------------------
elif nav_selection == "🔮 Prediction":
    st.markdown('<div class="main-title">Machine Learning Case Prediction</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">Predict future daily COVID-19 cases using autoregressive lag features and moving average indicators.</div>',
        unsafe_allow_html=True,
    )

    st.info(
        "ℹ️ **Academic Modeling Notice:** Predictions are generated using autoregressive machine learning algorithms trained on historical public reports. These projections are mathematical approximations for computer science project evaluation and are **not clinically validated or intended as medical advice**."
    )

    try:
        df = get_cached_dataset()
        saved_model, config = load_trained_model_and_config()

        country_options = ["Global"] + sorted(list(df["country"].unique()))

        p_col1, p_col2, p_col3 = st.columns([2, 1, 1])
        with p_col1:
            pred_region = st.selectbox("Select Target Region for Prediction:", country_options, index=0)
        with p_col2:
            forecast_days = st.slider("Forecast Horizon (Days):", min_value=3, max_value=30, value=7, step=1)
        with p_col3:
            st.write("")
            st.write("")
            run_pred_btn = st.button("🚀 Generate Prediction", type="primary", use_container_width=True)

        # Prepare target historical data
        if pred_region == "Global":
            ts_hist = get_global_time_series(df)[["date", "daily_cases"]].copy()
            model_to_use = saved_model
        else:
            c_df = df[df["country"] == pred_region].sort_values("date").reset_index(drop=True)
            ts_hist = c_df[["date", "daily_cases"]].copy()
            # Train a country-specific linear regressor on the fly
            feat_df, cols = create_time_series_features(ts_hist)
            m = LinearRegression()
            m.fit(feat_df[cols], feat_df["daily_cases"])
            model_to_use = m

        if model_to_use is None:
            # Fallback training if serialized model is missing
            feat_df, cols = create_time_series_features(ts_hist)
            model_to_use = LinearRegression()
            model_to_use.fit(feat_df[cols], feat_df["daily_cases"])

        feature_columns = config["feature_columns"] if config else [
            "cases_lag_1", "cases_lag_2", "cases_lag_3", "cases_lag_7", "cases_lag_14",
            "cases_rolling_mean_7", "cases_rolling_std_7", "cases_rolling_mean_14",
            "cases_rolling_std_14", "day_of_week", "day_of_year"
        ]

        # Generate Forecast
        forecast_df = forecast_future_days(
            model_to_use,
            ts_hist.tail(45),
            feature_cols=feature_columns,
            days=forecast_days,
        )

        st.markdown("---")
        st.markdown(f"### Forecast Results for {pred_region} (Next {forecast_days} Days)")

        # Summary KPIs for the forecasted period
        total_pred_cases = int(forecast_df["predicted_cases"].sum())
        avg_pred_daily = int(forecast_df["predicted_cases"].mean())
        last_known_cases = int(ts_hist.iloc[-1]["daily_cases"])
        trend_pct = ((avg_pred_daily - last_known_cases) / last_known_cases * 100) if last_known_cases > 0 else 0.0

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Projected Total Cases", f"{total_pred_cases:,}")
        m2.metric("Projected Daily Average", f"{avg_pred_daily:,}")
        m3.metric("Last Known Daily Cases", f"{last_known_cases:,}")
        m4.metric("Projected Trend vs Last Day", f"{trend_pct:+.1f}%")

        # Interactive Forecast Chart
        st.markdown("#### Historical vs. Predicted Trajectory")
        fig_pred = go.Figure()

        # Display recent 60 days of historical data for context
        recent_hist = ts_hist.tail(60)
        fig_pred.add_trace(
            go.Scatter(
                x=recent_hist["date"],
                y=recent_hist["daily_cases"],
                mode="lines",
                name="Historical Daily Cases",
                line=dict(color="#1E3A8A", width=2.5),
            )
        )

        # Connect last historical point to first forecasted point
        connect_df = pd.concat([recent_hist.tail(1)[["date", "daily_cases"]].rename(columns={"daily_cases": "predicted_cases"}), forecast_df], ignore_index=True)

        fig_pred.add_trace(
            go.Scatter(
                x=connect_df["date"],
                y=connect_df["predicted_cases"],
                mode="lines+markers",
                name="ML Forecast",
                line=dict(color="#10B981", width=3, dash="dash"),
                marker=dict(size=6, color="#10B981"),
            )
        )

        fig_pred.update_layout(
            template="plotly_white",
            margin=dict(l=20, r=20, t=30, b=20),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
            xaxis_title="Date",
            yaxis_title="Daily Cases",
            hovermode="x unified",
        )
        st.plotly_chart(fig_pred, use_container_width=True)

        # Tabular Forecast Details
        st.markdown("#### Daily Forecast Breakdown")
        display_forecast = forecast_df.copy()
        display_forecast["Date"] = display_forecast["date"].dt.strftime("%Y-%m-%d (%A)")
        display_forecast["Predicted Cases"] = display_forecast["predicted_cases"].apply(lambda v: f"{int(round(v)):,}")
        st.dataframe(display_forecast[["Date", "Predicted Cases"]], use_container_width=True)

    except Exception as e:
        st.error(f"Error generating predictions: {e}")


# -----------------------------------------------------------------------------
# 4. MODEL PERFORMANCE SECTION
# -----------------------------------------------------------------------------
elif nav_selection == "🏆 Model Performance":
    st.markdown('<div class="main-title">Model Evaluation & Benchmark</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">Evaluation metrics on unseen chronological test data (November 2021 – April 2022).</div>',
        unsafe_allow_html=True,
    )

    try:
        _, config = load_trained_model_and_config()

        # Actual metrics from training pipeline
        metrics_data = [
            {
                "Model": "Linear Regression",
                "MAE": "153,028.9",
                "RMSE": "227,294.9",
                "R² Score": "0.9432",
                "Status": "⭐ Best Performing",
            },
            {
                "Model": "Random Forest Regressor",
                "MAE": "833,483.3",
                "RMSE": "1,193,694.2",
                "R² Score": "-0.5660",
                "Status": "Suboptimal Extrapolation",
            },
            {
                "Model": "Gradient Boosting Regressor",
                "MAE": "863,587.3",
                "RMSE": "1,224,839.4",
                "R² Score": "-0.6488",
                "Status": "Suboptimal Extrapolation",
            },
        ]
        perf_df = pd.DataFrame(metrics_data)

        st.markdown(
            """
            <div style="background-color: #ECFDF5; border: 1px solid #A7F3D0; border-radius: 8px; padding: 1rem; margin-bottom: 1.5rem;">
                <span class="badge-best">SELECTED BEST MODEL</span>
                <strong style="color: #065F46; font-size: 1.1rem; margin-left: 0.5rem;">Linear Regression</strong>
                <p style="color: #047857; margin-top: 0.5rem; font-size: 0.95rem; margin-bottom: 0;">
                    Linear Regression achieved the lowest RMSE (227,294.9) and highest R² (0.9432) on the unseen chronological test set.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.markdown("#### Evaluation Metric Comparison Table")
        st.table(perf_df)

        st.markdown("---")

        # Metric breakdown cards
        c1, c2, c3 = st.columns(3)
        with c1:
            st.metric("Linear Regression R²", "0.9432", "Explains 94.3% of variance")
        with c2:
            st.metric("Linear Regression MAE", "153,029", "Average absolute error")
        with c3:
            st.metric("Linear Regression RMSE", "227,295", "Penalizes large deviations")

        st.markdown("---")

        # Actual vs Predicted Test Plot
        st.markdown("#### Actual vs. Predicted on Chronological Test Set")
        test_img_path = PROJECT_ROOT / "reports" / "figures" / "actual_vs_predicted.png"
        if test_img_path.exists():
            st.image(str(test_img_path), caption="Model Predictions on Unseen Test Split", use_column_width=True)
        else:
            st.info("Run `train_model.py` to regenerate the test split comparison figure.")

        st.markdown("#### 💡 Why Did Linear Regression Outperform Decision Tree Models?")
        st.markdown(
            r"""
            * **Extrapolation Limitation of Tree Ensembles:** Tree models (Random Forest and Gradient Boosting) partition the training feature space into orthogonal leaves. When predicting, they output the mean of samples in the terminal leaf, bounded by the maximum seen in training ($\sim$900k cases/day).
            * **Unseen Epidemic Surge:** During the chronological test window (November 2021 – April 2022), the global Omicron wave surged up to **4,089,026 cases/day**. Tree models could not predict values beyond their training ceiling, leading to negative $R^2$.
            * **Linear Proportional Scaling:** Linear Regression models continuous lag relationships ($y_t \approx \beta_1 y_{t-1} + \dots$), allowing predictions to naturally scale upward during unprecedented waves.
            """
        )

    except Exception as e:
        st.error(f"Error displaying performance metrics: {e}")


# -----------------------------------------------------------------------------
# 5. DATASET SECTION
# -----------------------------------------------------------------------------
elif nav_selection == "📁 Dataset":
    st.markdown('<div class="main-title">COVID-19 Dataset Explorer</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">Inspect project data, check data hygiene, or upload a custom CSV for verification.</div>',
        unsafe_allow_html=True,
    )

    try:
        uploaded_file = st.file_uploader("Upload custom CSV file (optional):", type=["csv"])

        if uploaded_file is not None:
            st.success("Custom CSV uploaded successfully!")
            active_df = pd.read_csv(uploaded_file)
            dataset_source = f"Uploaded File: {uploaded_file.name}"
        else:
            active_df = get_cached_dataset()
            dataset_source = "Default Project Dataset (Johns Hopkins University CSSE)"

        st.markdown(f"**Current Dataset**: `{dataset_source}`")

        # Dataset Dimensions
        col_m1, col_m2, col_m3 = st.columns(3)
        col_m1.metric("Total Rows", f"{active_df.shape[0]:,}")
        col_m2.metric("Total Columns", f"{active_df.shape[1]}")
        col_m3.metric("Total Missing Cells", f"{int(active_df.isnull().sum().sum()):,}")

        st.markdown("---")

        # Column Names & Missing Values
        d_c1, d_c2 = st.columns([1, 1])

        with d_c1:
            st.markdown("#### Column Information & Data Types")
            col_info = pd.DataFrame(
                {
                    "Column Name": active_df.columns,
                    "Data Type": [str(t) for t in active_df.dtypes],
                }
            )
            st.dataframe(col_info, use_container_width=True)

        with d_c2:
            st.markdown("#### Missing Values per Column")
            null_info = pd.DataFrame(
                {
                    "Column Name": active_df.columns,
                    "Missing Count": active_df.isnull().sum().values,
                    "Missing (%)": (active_df.isnull().sum().values / len(active_df) * 100).round(2),
                }
            )
            st.dataframe(null_info, use_container_width=True)

        st.markdown("---")

        # First 10 Rows
        st.markdown("#### Dataset Preview (First 10 Rows)")
        st.dataframe(active_df.head(10), use_container_width=True)

        # Download CSV
        csv_data = active_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="📥 Download Dataset as CSV",
            data=csv_data,
            file_name="covid_dataset_export.csv",
            mime="text/csv",
        )

    except Exception as e:
        st.error(f"Error inspecting dataset: {e}")
